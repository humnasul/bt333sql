-- -----------------------------------------------------
-- Schema Turtles
-- -----------------------------------------------------
DROP DATABASE IF EXISTS Turtles;
CREATE DATABASE  `Turtles` DEFAULT CHARACTER SET latin1 COLLATE latin1_general_cs ;
